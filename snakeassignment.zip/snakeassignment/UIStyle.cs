﻿using System.Drawing;
using System.Windows.Forms;

namespace snakeassignment
{
    // MUST be partial to extend the existing SettingsForm class
    public partial class SettingsForm
    {
        // Private method to encapsulate all design and layout code
        private void DesignControls()
        {
            // --- 1. Form Setup and Global Styling ---

            // NOTE: The sizing and basic form properties should still be called via InitializeComponent() 
            // in the Designer.cs or manually here if InitializeComponent() is not used.
            this.Text = "Settings";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 420;
            this.Height = 260;

            // Applying the dark/neon theme to the Settings form
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.ForeColor = Color.White;

            // --- 2. Positioning and Sizing (Transferring original code from constructor) ---

            // Positioning Buttons
            btnSnakeColor.Location = new Point(20, 20);
            btnSnakeColor.Size = new Size(120, 30);

            btnBoardColor.Location = new Point(20, 60);
            btnBoardColor.Size = new Size(120, 30);

            btnFoodColor.Location = new Point(20, 100);
            btnFoodColor.Size = new Size(120, 30);

            // Positioning Previews
            previewSnake.Location = new Point(160, 20);
            previewSnake.Size = new Size(60, 30);

            previewBoard.Location = new Point(160, 60);
            previewBoard.Size = new Size(60, 30);

            previewFood.Location = new Point(160, 100);
            previewFood.Size = new Size(60, 30);

            // Checkbox
            chkEnableSound.Location = new Point(20, 150);

            // OK/Cancel Buttons (Adjusted Top to 180 for better spacing)
            btnOk.Location = new Point(220, 180);
            btnOk.Size = new Size(80, 30);

            btnCancel.Location = new Point(310, 180);
            btnCancel.Size = new Size(80, 30);

            // --- 3. Neon Styling for Controls ---

            void ApplyButtonStyle(Button btn)
            {
                btn.BackColor = Color.FromArgb(50, 50, 50);
                btn.ForeColor = Color.Cyan;
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 1;
                btn.FlatAppearance.BorderColor = Color.Cyan;
            }

            ApplyButtonStyle(btnSnakeColor);
            ApplyButtonStyle(btnBoardColor);
            ApplyButtonStyle(btnFoodColor);
            ApplyButtonStyle(btnOk);
            ApplyButtonStyle(btnCancel);

            chkEnableSound.ForeColor = Color.YellowGreen;
        }
    }
}