﻿using System.Drawing;
using System.Windows.Forms;

namespace snakeassignment
{
    // The 'partial' keyword is essential to extend the existing SettingsForm class
    public partial class SettingsForm
    {
        /// <summary>
        /// Contains all sizing, positioning, and visual styling for the SettingsForm controls.
        /// </summary>
        private void DesignControls()
        {
            // --- 1. Form Setup and Global Styling ---

            // NOTE: The sizing (Width, Height, BorderStyle) is already set in the constructor, 
            // but we can apply the theme colors here.

            this.BackColor = Color.FromArgb(30, 30, 30); // Dark background 
            this.ForeColor = Color.White;                // White text for general contrast

            // --- 2. Positioning and Sizing ---

            // Positioning Buttons
            btnSnakeColor.Location = new Point(20, 20);
            btnSnakeColor.Size = new Size(120, 30);

            btnBoardColor.Location = new Point(20, 60);
            btnBoardColor.Size = new Size(120, 30);

            btnFoodColor.Location = new Point(20, 100);
            btnFoodColor.Size = new Size(120, 30);

            // Positioning Color Previews (Panels)
            previewSnake.Location = new Point(160, 20);
            previewSnake.Size = new Size(60, 30);

            previewBoard.Location = new Point(160, 60);
            previewBoard.Size = new Size(60, 30);

            previewFood.Location = new Point(160, 100);
            previewFood.Size = new Size(60, 30);

            // Checkbox
            chkEnableSound.Location = new Point(20, 150);

            // OK/Cancel Buttons (Adjusted Top to 180 for better vertical separation)
            btnOk.Location = new Point(220, 180);
            btnOk.Size = new Size(80, 30);

            btnCancel.Location = new Point(310, 180);
            btnCancel.Size = new Size(80, 30);

            // --- 3. Neon Styling for Controls ---

            // Helper function for applying the button style
            void ApplyButtonStyle(Button btn)
            {
                btn.BackColor = Color.FromArgb(50, 50, 50); // Darker gray fill
                btn.ForeColor = Color.Cyan;                 // Bright text color
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 1;
                btn.FlatAppearance.BorderColor = Color.Cyan; // Neon border
                btn.Font = new Font(btn.Font.FontFamily, 10f, FontStyle.Bold);
            }

            ApplyButtonStyle(btnSnakeColor);
            ApplyButtonStyle(btnBoardColor);
            ApplyButtonStyle(btnFoodColor);
            ApplyButtonStyle(btnOk);
            ApplyButtonStyle(btnCancel);

            chkEnableSound.ForeColor = Color.YellowGreen; // Highlighting the checkbox
            chkEnableSound.Font = new Font(chkEnableSound.Font.FontFamily, 10f, FontStyle.Bold);
        }
    }
}