﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using System.Media; 
using System.Drawing.Drawing2D; 

namespace snakeassignment
{
    public partial class Form1 : Form

    {
        private Color customSnakeHeadColor;
        private Color customSnakeBodyColor;
        private Color customBoardColor;
        private Color customFoodColor;
        private bool useCustomColors = false; 
        private bool soundEnabled = true; 

        private int selectedSpeed = 150;
        private Theme currentTheme;
        const int InitialInterval = 150;

        float cellWidth = 25;
        float cellHeight = 25;
        int rows = 20;
        int cols = 20;

        List<Point> snake = new List<Point>();

        private NormalFood? normalFood;
        private SpecialFood? specialFood;

        string direction = "right";
        bool isPlaying = false;
        bool isPaused = false;

        private System.Windows.Forms.Timer specialFoodTimer = new System.Windows.Forms.Timer();
        const int SpecialFoodDuration = 7000; // 7 seconds (updated per request)

        public int temporarySpeedAdjustment = 0;
        System.Windows.Forms.Timer gameTimer = new System.Windows.Forms.Timer();
        Random rand = new Random();

        int score = 0;
        int highScore = 0;

        public Form1()
        {
            InitializeComponent();
            btnSetting.Click += btnSetting_Click;
           
            // Set default checked
            rdoSpeedNormal.Checked = true;
            ApplyTheme(GameTheme.Neon);

            //  Apply custom styling to GroupBoxes and RadioButtons

            // Setup GroupBoxes
            SetupGroupBox(grpSpeedSelector);
            SetupGroupBox(grpThemeSelector);

            // Setup RadioButtons (Speed)
            SetupRadioButton(rdoVerySlow);
            SetupRadioButton(rdoSpeedSlow);
            SetupRadioButton(rdoSpeedNormal);
            SetupRadioButton(rdoSpeedFast);
            SetupRadioButton(rdoSpeedExtreme);

            // Setup RadioButtons (Theme)
            SetupRadioButton(rdoDarkTheme);
            SetupRadioButton(rdoLightTheme);
            SetupRadioButton(rdoNeonTheme);

            // Speed Selection Setup (Attach handlers)
            rdoSpeedExtreme.CheckedChanged += SpeedRadioButton_CheckedChanged;
            rdoSpeedFast.CheckedChanged += SpeedRadioButton_CheckedChanged;
            rdoSpeedNormal.CheckedChanged += SpeedRadioButton_CheckedChanged;
            rdoSpeedSlow.CheckedChanged += SpeedRadioButton_CheckedChanged;
            rdoVerySlow.CheckedChanged += SpeedRadioButton_CheckedChanged;

            // Theme Selection Setup (Attach handlers)
            rdoDarkTheme.CheckedChanged += rdoDarkTheme_CheckedChanged;
            rdoLightTheme.CheckedChanged += rdoLightTheme_CheckedChanged;
            rdoNeonTheme.CheckedChanged += rdoNeonTheme_CheckedChanged;


            if (grpThemeSelector != null)
            {
                grpThemeSelector.Enabled = true;
            }

            // Double Buffering setup
            typeof(Panel).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, pnlGame, new object[] { true });

            lblScore.BackColor = Color.Transparent;
            lblHighScore.BackColor = Color.Transparent;

            lblScore.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblHighScore.Font = new Font("Segoe UI", 14, FontStyle.Bold);

            // Button styling setup
            SetupButton(btnStart);
            SetupButton(btnPause);
            SetupButton(btnRestart);
            SetupButton(btnSetting);


            btnStart.Visible = true;
            btnPause.Visible = false;
            btnRestart.Visible = false;

            gameTimer.Interval = InitialInterval;
            gameTimer.Tick += GameTimer_Tick;
            this.KeyPreview = true;
            this.ActiveControl = null;
            this.KeyDown += new KeyEventHandler(Form1_KeyDown);

            // 💡 NEW: Special Food Timer setup (7s)
            specialFoodTimer.Interval = SpecialFoodDuration;
            specialFoodTimer.Tick += SpecialFoodTimer_Tick;

            lblMessage.Enabled = false;
            lblMessage.Text = "PRESS 'START GAME' TO BEGIN.\nUSE ARROW KEYS TO MOVE.";
            lblMessage.Visible = true;

            this.DoubleBuffered = true;
        }

        // 💡 NEW: Handler for the Special Food Timer
        private void SpecialFoodTimer_Tick(object? sender, EventArgs e)
        {
            specialFoodTimer.Stop();
            // 🐛 FIX: Ensure we only clear the Special Food if it wasn't eaten already
            if (specialFood != null)
            {
                specialFood = null; // Special food disappears
                pnlGame.Invalidate(); // Redraw the panel
            }
        }


        // ----------------------------------------------------------------------
        // 💡 NEW UI SETUP METHODS
        // ----------------------------------------------------------------------

        private void SetupGroupBox(GroupBox grp)
        {
            grp.BackColor = Color.Transparent;
            grp.ForeColor = currentTheme.Primary; // Use primary theme color for text
            grp.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            grp.FlatStyle = FlatStyle.Flat;

            // Custom Paint event for the GroupBox
            grp.Paint += (s, e) =>
            {
                GroupBox? box = s as GroupBox;
                if (box == null) return;

                Graphics g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;

                // 1. Draw rounded, semi-transparent background fill
                Rectangle rect = new Rectangle(0, 10, box.Width - 1, box.Height - 11);
                int radius = 10;

                using (GraphicsPath path = new GraphicsPath())
                {
                    path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                    path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                    path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                    path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
                    path.CloseFigure();

                    // Semi-transparent panel background color
                    using (SolidBrush fillBrush = new SolidBrush(Color.FromArgb(50, currentTheme.PanelBackground)))
                    {
                        g.FillPath(fillBrush, path);
                    }

                    // 2. Draw border
                    using (Pen borderPen = new Pen(currentTheme.Primary, 2))
                    {
                        g.DrawPath(borderPen, path);
                    }
                }

                // 3. Draw Title (TextRenderer handles transparent background better)
                if (!string.IsNullOrEmpty(box.Text))
                {
                    SizeF textSize = g.MeasureString(box.Text, box.Font);
                    Rectangle textRect = new Rectangle(10, 0, (int)textSize.Width + 5, (int)textSize.Height + 2);

                    // Cover the border line where the text is placed with the parent's background color
                    if (box.Parent != null)
                    {
                        using (SolidBrush backgroundFill = new SolidBrush(box.Parent.BackColor))
                        {
                            g.FillRectangle(backgroundFill, textRect);
                        }
                    }

                    // Draw the text
                    TextRenderer.DrawText(g, box.Text, box.Font, textRect, box.ForeColor, TextFormatFlags.VerticalCenter);
                }
            };
        }

        private void SetupRadioButton(RadioButton rb)
        {
            rb.Appearance = Appearance.Button;
            rb.FlatStyle = FlatStyle.Flat;
            rb.FlatAppearance.BorderSize = 0;
            rb.BackColor = Color.Transparent;
            rb.ForeColor = currentTheme.Primary;
            rb.Font = new Font("Segoe UI", 9, FontStyle.Regular);
            rb.Cursor = Cursors.Hand;
            rb.TextAlign = ContentAlignment.MiddleCenter;


            // Custom Paint event for the RadioButton
            rb.Paint += (s, e) =>
            {
                RadioButton? button = s as RadioButton;
                if (button == null) return;

                Graphics g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                Rectangle rect = new Rectangle(0, 0, button.Width, button.Height);
                int radius = 15;

                Color accentColor = currentTheme.Primary;

                using (GraphicsPath path = new GraphicsPath())
                {
                    // Create a rounded rectangle path
                    path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                    path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                    path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                    path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
                    path.CloseFigure();

                    Color fill;
                    Color border;

                    if (button.Checked)
                    {
                        // Checked State: Strong primary color fill, white text
                        fill = accentColor;
                        border = accentColor;
                        button.ForeColor = Color.White;
                    }
                    else
                    {
                        // Unchecked State: Semi-transparent fill, primary color text
                        fill = Color.FromArgb(20, accentColor);
                        border = accentColor;
                        button.ForeColor = accentColor;
                    }

                    // Draw the custom button shape
                    using (SolidBrush b = new SolidBrush(fill)) g.FillPath(b, path);
                    using (Pen p = new Pen(border, 1.5f)) g.DrawPath(p, path);
                }

                // Draw the text in the center
                TextRenderer.DrawText(g, button.Text, button.Font, rect, button.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

            // Force redraw when mouse enters/leaves or state changes
            rb.MouseEnter += (s, e) => rb.Invalidate();
            rb.MouseLeave += (s, e) => rb.Invalidate();
            rb.CheckedChanged += (s, e) => rb.Invalidate();
        }

        // ----------------------------------------------------------------------
        // 💡 THEME MANAGEMENT METHODS (Updated to redraw new controls)
        // ----------------------------------------------------------------------

        private void ApplyTheme(GameTheme themeType)
        {
            currentTheme = Theme.GetTheme(themeType);

            // 1. Apply colors to static controls
            lblScore.ForeColor = currentTheme.Primary;
            lblHighScore.ForeColor = currentTheme.Secondary;
            lblMessage.ForeColor = currentTheme.MessageText;

            // 2. Update Button ForeColors and force redraw for custom Paint logic
            if (btnStart != null) btnStart.ForeColor = currentTheme.Secondary;
            if (btnPause != null) btnPause.ForeColor = currentTheme.Secondary;
            if (btnRestart != null) btnRestart.ForeColor = currentTheme.Secondary;

            // Force the entire form and game panel to redraw
            this.Invalidate();
            pnlGame.Invalidate();

            // ⭐ NEW: Force redraw of GroupBoxes and all RadioButtons to apply new colors
            grpSpeedSelector.Invalidate();
            grpThemeSelector.Invalidate();

            // Helper to invalidate all controls within a container
            Action<Control> invalidateChildren = (container) =>
            {
                foreach (Control control in container.Controls)
                {
                    control.Invalidate();
                }
            };

            invalidateChildren(grpSpeedSelector);
            invalidateChildren(grpThemeSelector);
        }

        // ----------------------------------------------------------------------
        // UI DRAWING METHODS (Mostly Unchanged)
        // ----------------------------------------------------------------------

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (System.Drawing.Drawing2D.LinearGradientBrush brush =
                new System.Drawing.Drawing2D.LinearGradientBrush(
                    this.ClientRectangle,
                    currentTheme.MainBackgroundStart,
                    currentTheme.MainBackgroundEnd,
                    90F))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // Draw Score Borders
            if (lblScore != null && lblHighScore != null)
            {
                Rectangle scoreRect = new Rectangle(lblScore.Left - 10, lblScore.Top - 5, lblScore.Width + 20, lblScore.Height + 10);
                DrawRoundedBorder(g, scoreRect, currentTheme.Primary);

                Rectangle highRect = new Rectangle(lblHighScore.Left - 10, lblHighScore.Top - 5, lblHighScore.Width + 20, lblHighScore.Height + 10);
                DrawRoundedBorder(g, highRect, currentTheme.Secondary);
            }
        }

        private void DrawRoundedBorder(Graphics g, Rectangle rect, Color color)
        {
            int radius = 15;
            using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
            using (Pen pen = new Pen(color, 2))
            {
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
                path.CloseFigure();
                g.DrawPath(pen, path);
            }
        }

        private void SetupButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btn.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btn.BackColor = Color.Transparent;
            btn.ForeColor = currentTheme?.Secondary ?? Color.White;
            btn.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            btn.Cursor = Cursors.Hand;

            // Custom Paint for Rounded Pill Shape
            btn.Paint += (s, e) =>
            {
                Graphics g = e.Graphics;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                Rectangle rect = new Rectangle(0, 0, btn.Width, btn.Height);
                int radius = 20;

                using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                    path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                    path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                    path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
                    path.CloseFigure();

                    // Hover effect
                    Color accentColor = currentTheme.Secondary;
                    Color fill = btn.ClientRectangle.Contains(btn.PointToClient(Cursor.Position)) ?
                                 Color.FromArgb(60, accentColor) : Color.FromArgb(20, accentColor);

                    using (SolidBrush b = new SolidBrush(fill)) g.FillPath(b, path);
                    using (Pen p = new Pen(accentColor, 2)) g.DrawPath(p, path);
                }
                TextRenderer.DrawText(g, btn.Text, btn.Font, rect, btn.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };
        }

        private void lblHighScore_Click(object? sender, EventArgs e)
        {
            // Empty
        }

        private void pnlGame_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // 1. Draw Background (Fill the whole panel)
            Color boardColor = useCustomColors && customBoardColor != Color.Empty
                               ? customBoardColor
                               : currentTheme.PanelBackground;

            using (SolidBrush bg = new SolidBrush(boardColor))
            {
                g.FillRectangle(bg, 0, 0, pnlGame.Width, pnlGame.Height);
            }

            // 2. Draw Grid Lines
            using (Pen gridPen = new Pen(Color.FromArgb(80, currentTheme.Primary), 1))
            {
                // Vertical lines
                for (int i = 0; i <= cols; i++)
                {
                    float x = i * cellWidth;
                    g.DrawLine(gridPen, x, 0, x, pnlGame.Height);
                }
                // Horizontal lines
                for (int j = 0; j <= rows; j++)
                {
                    float y = j * cellHeight;
                    g.DrawLine(gridPen, 0, y, pnlGame.Width, y);
                }
            }

            // 3. Draw Snake
            for (int i = 0; i < snake.Count; i++)
            {
                Point part = snake[i];

                // Use floating point coordinates for smoother stretching
                RectangleF partRect = new RectangleF(
                    part.X * cellWidth,
                    part.Y * cellHeight,
                    cellWidth - 1,
                    cellHeight - 1
                );

                Color headColor = useCustomColors && customSnakeHeadColor != Color.Empty ? customSnakeHeadColor : currentTheme.SnakeHead;
                Color bodyColor = useCustomColors && customSnakeBodyColor != Color.Empty ? customSnakeBodyColor : currentTheme.SnakeBody;

                using (SolidBrush brush = new SolidBrush(i == 0 ? headColor : bodyColor))
                {
                    g.FillRectangle(brush, partRect);
                }
            }

            // 4. Draw Food (Pass the new resizing logic)
            DrawFoodItem(g, normalFood);
            DrawFoodItem(g, specialFood);

            // 5. Draw Border (Outer Frame)
            using (Pen p = new Pen(currentTheme.Primary, 3))
            {
                g.DrawRectangle(p, 0, 0, pnlGame.Width - 1, pnlGame.Height - 1);
            }
        }

        private void DrawFoodItem(Graphics g, FoodBase? foodItem)
        {
            if (foodItem != null)
            {
                // Calculate position using the new Width/Height variables
                RectangleF foodRect = new RectangleF(
                    foodItem.Position.X * cellWidth,
                    foodItem.Position.Y * cellHeight,
                    cellWidth - 1,
                    cellHeight - 1
                );

                g.FillEllipse(new SolidBrush(foodItem.Color), foodRect);

                using (Pen glow = new Pen(Color.FromArgb(100, foodItem.Color), 2))
                {
                    g.DrawEllipse(glow, foodRect);
                }
            }
        }

        // ----------------------------------------------------------------------
        // GAME LOGIC METHODS 
        // ----------------------------------------------------------------------

        // CORE GAME RESET LOGIC (Called by Start and Restart)
        private void ResetGameLogic()
        {
            snake.Clear();
            snake.Add(new Point(10, 10));
            snake.Add(new Point(9, 10));
            snake.Add(new Point(8, 10));

            direction = "right";
            // Uses the user's selected speed
            gameTimer.Interval = selectedSpeed;
            temporarySpeedAdjustment = 0;

            score = 0;
            lblScore.Text = "Score: " + score;

            // 💡 RESET special food state
            specialFood = null;
            specialFoodTimer.Stop();

            PlaceFood();

            lblMessage.Visible = false;

            isPlaying = true;
            isPaused = false;
            pnlGame.Focus();
            gameTimer.Start();

            pnlGame.Invalidate();
        }

        //  UPDATED: PlaceFood now spawns NORMAL food (always) and SPECIAL food (20% chance)
        private void PlaceFood()
        {
            Point normalPos;
            do
            {
                int x = rand.Next(0, cols);
                int y = rand.Next(0, rows);
                normalPos = new Point(x, y);
            } while (snake.Contains(normalPos)); // Ensure normal food doesn't spawn on the snake

            normalFood = new NormalFood { Position = normalPos };

            // 1 in 5 chance (20%) for special food to appear, AND only if no special food is currently on screen
            if (rand.Next(1, 6) == 1 && specialFood == null)
            {
                Point specialPos;
                do
                {
                    int x = rand.Next(0, cols);
                    int y = rand.Next(0, rows);
                    specialPos = new Point(x, y);
                    // Ensure special food doesn't spawn on the snake or on top of the normal food
                } while (snake.Contains(specialPos) || specialPos == normalFood.Position);

                
                List<FoodType> weightedSpecials = new List<FoodType>
                {
                    FoodType.Bomb, FoodType.Bomb, FoodType.Bomb, // Bomb weight = 3
                    FoodType.Fast,                                // Fast weight = 1
                    FoodType.Slow,                                // Slow weight = 1
                    FoodType.Bonus                                // Bonus weight = 1
                };

                FoodType chosen = weightedSpecials[rand.Next(weightedSpecials.Count)];

                specialFood = new SpecialFood(chosen) { Position = specialPos };

                // Start the special food timer (7 seconds)
                specialFoodTimer.Start();
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            // Add any setup code you need here
        }
        private void GameTimer_Tick(object sender, EventArgs e)
        {
            MoveSnake();
            pnlGame.Invalidate();
        }

        private void MoveSnake()
        {
            if (!isPlaying) return;

            // 1️⃣ Get current head & 2️⃣ Determine new head position
            Point head = snake[0];
            Point newHead = head;

            if (direction == "up") newHead = new Point(head.X, head.Y - 1);
            else if (direction == "down") newHead = new Point(head.X, head.Y + 1);
            else if (direction == "left") newHead = new Point(head.X - 1, head.Y);
            else if (direction == "right") newHead = new Point(head.X + 1, head.Y);

            // 3️⃣ Check wall collision & 4️⃣ Check self collision (Unchanged)
            if (newHead.X < 0 || newHead.X >= cols || newHead.Y < 0 || newHead.Y >= rows || snake.Contains(newHead))
            {
                GameOver();
                return;
            }

            // 5️⃣ Move snake
            snake.Insert(0, newHead);

            // 6️⃣ Check food collision
            bool foodWasEaten = false;
            FoodBase? eatenFood = null;

            // Check Special Food first (as it might expire)
            if (specialFood != null && newHead == specialFood.Position)
            {
                eatenFood = specialFood;
                foodWasEaten = true;
                specialFood = null; // Special food is eaten
                specialFoodTimer.Stop(); // Stop the timer if eaten
            }
            // Check Normal Food
            else if (normalFood != null && newHead == normalFood.Position)
            {
                eatenFood = normalFood;
                foodWasEaten = true;
                // Normal food is immediately replaced in PlaceFood()
            }

            if (foodWasEaten && eatenFood != null)
            {
                // Apply food type effects (updates temporarySpeedAdjustment inside)
                eatenFood.ApplyEffect(this);

                if (!isPlaying)
                    return;

                score += eatenFood.Points;
                lblScore.Text = "Score: " + score;

                if (score > highScore)
                {
                    highScore = score;
                    lblHighScore.Text = "High Score: " + highScore;
                }

                // Level-based permanent speed increase
                int pointsPerLevel = 50;
                int speedReductionPerLevel = 10;
                int currentLevel = score / pointsPerLevel;

                // Base speed is the user's selected speed minus the level reduction
                int baseSpeed = selectedSpeed - (currentLevel * speedReductionPerLevel);

                // Calculate FINAL Interval: Base Speed + Temporary Adjustment (from food)
                gameTimer.Interval = Math.Max(50, baseSpeed + temporarySpeedAdjustment);

                // Play eating sound
                if (soundEnabled)
                {
                    SystemSounds.Beep.Play();
                    Console.Beep(800, 150);
                }

                // Place new food items
                PlaceFood();
            }
            else
            {
                
                if (temporarySpeedAdjustment != 0)
                {
                    // Recalculate the level-based base speed using selectedSpeed
                    int pointsPerLevel = 50;
                    int speedReductionPerLevel = 10;
                    int currentLevel = score / pointsPerLevel;
                    int baseSpeed = selectedSpeed - (currentLevel * speedReductionPerLevel);

                    temporarySpeedAdjustment = 0;
                    gameTimer.Interval = Math.Max(50, baseSpeed);
                }

                // Remove tail if no food eaten (standard snake movement)
                snake.RemoveAt(snake.Count - 1);
            }
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Visible = false;
            btnRestart.Visible = false;
            btnPause.Visible = true;
            grpSpeedSelector.Enabled = false;

            if (grpThemeSelector != null)
            {
                grpThemeSelector.Enabled = false;
            }

            ResetGameLogic();
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            btnRestart.Visible = false;
            btnStart.Visible = false;
            btnPause.Visible = true;

            if (grpThemeSelector != null)
            {
                grpThemeSelector.Enabled = false;
            }

            ResetGameLogic();
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            if (!isPlaying) return;

            if (!isPaused)
            {
                gameTimer.Stop();
                specialFoodTimer.Stop(); // 💡 PAUSE special food timer
                isPaused = true;
                btnPause.Text = "Resume";
                lblMessage.Text = "GAME PAUSED\nPress 'Resume' or a movement key to continue.";
                lblMessage.Visible = true;
            }
            else
            {
                gameTimer.Start();
                //  RESUME special food timer only if a special food is active
                if (specialFood != null)
                {
                    specialFoodTimer.Start();
                }

                isPaused = false;
                btnPause.Text = "Pause";
                lblMessage.Visible = false;
            }
        }

        // GAME OVER HANDLER
        private void GameOver()
        {
            grpSpeedSelector.Enabled = true;
            if (soundEnabled)
            {
                SystemSounds.Exclamation.Play();
                Console.Beep(400, 500);
            }

            gameTimer.Stop();
            specialFoodTimer.Stop(); // STOP special food timer

            //  FIX: Use the correctly declared variable 'isPlaying'
            isPlaying = false;

            isPaused = false;

            // 1. Construct the message with the final score
            lblMessage.Text = $"GAME OVER!\nFinal Score: {score}\nClick Restart Game to play again.";
            lblMessage.Visible = true;

            btnStart.Visible = false;
            btnPause.Visible = false;
            btnRestart.Visible = true;

            //  THEME : Re-enable the theme selector group box
            if (grpThemeSelector != null)
            {
                grpThemeSelector.Enabled = true;
            }
        }

        private void Form1_KeyDown(object? sender, KeyEventArgs e)
        {
            if (!isPlaying || isPaused) return;

            if ((e.KeyCode == Keys.W || e.KeyCode == Keys.Up) && direction != "down")
                direction = "up";
            else if ((e.KeyCode == Keys.S || e.KeyCode == Keys.Down) && direction != "up")
                direction = "down";
            else if ((e.KeyCode == Keys.A || e.KeyCode == Keys.Left) && direction != "right")
                direction = "left";
            else if ((e.KeyCode == Keys.D || e.KeyCode == Keys.Right) && direction != "left")
                direction = "right";

        }


        // ----------------------------------------------------------------------
        // RADIO BUTTON HANDLERS
        // ----------------------------------------------------------------------

        private void rdoDarkTheme_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton? rb = sender as RadioButton;
            if (rb != null && rb.Checked)
                ApplyTheme(GameTheme.Dark);
        }

        private void rdoLightTheme_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton? rb = sender as RadioButton;
            if (rb != null && rb.Checked)
                ApplyTheme(GameTheme.Light);
        }

        private void rdoNeonTheme_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton? rb = sender as RadioButton;
            if (rb != null && rb.Checked)
                ApplyTheme(GameTheme.Neon);
        }

        private void SpeedRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton? rb = sender as RadioButton;
            if (rb != null && rb.Checked)
            {
                // Safety check to ensure the Tag is a positive number
                if (int.TryParse(rb.Tag?.ToString(), out int newSpeed) && newSpeed > 0)
                {
                    selectedSpeed = newSpeed; // update selected speed

                    // Only update the timer interval if the game is already running or paused.
                    if (isPlaying || isPaused)
                    {
                        ApplyNewSelectedSpeed();
                    }
                }
            }
        }

        //  HELPER METHOD: Applies the selected speed to the running timer.
        private void ApplyNewSelectedSpeed()
        {
            // Stop any temporary speed effect by resetting the interval based on the new selected speed
            temporarySpeedAdjustment = 0;

            // Recalculate the level-based base speed using selectedSpeed
            int pointsPerLevel = 50;
            int speedReductionPerLevel = 10;
            int currentLevel = score / pointsPerLevel;
            int baseSpeed = selectedSpeed - (currentLevel * speedReductionPerLevel);

            gameTimer.Interval = Math.Max(50, baseSpeed);
        }

        public enum GameTheme { Neon, Dark, Light }

        public class Theme
        {
            public Color Primary { get; set; }
            public Color Secondary { get; set; }
            public Color MainBackgroundStart { get; set; }
            public Color MainBackgroundEnd { get; set; }
            public Color PanelBackground { get; set; }
            public Color MessageText { get; set; }
            public Color SnakeBody { get; set; }
            public Color SnakeHead { get; set; }

            public static Theme GetTheme(GameTheme themeType)
            {
                return themeType switch
                {
                    GameTheme.Neon => new Theme // The Original Theme
                    {
                        Primary = Color.FromArgb(0, 255, 136),      // Neon Teal
                        Secondary = Color.FromArgb(255, 215, 0),    // Gold
                        MainBackgroundStart = Color.FromArgb(20, 20, 40),
                        MainBackgroundEnd = Color.FromArgb(5, 5, 10),
                        PanelBackground = Color.FromArgb(10, 10, 20),
                        MessageText = Color.White,
                        SnakeBody = Color.FromArgb(200, 0, 255, 136),
                        SnakeHead = Color.White
                    },

                    GameTheme.Dark => new Theme
                    {
                        Primary = Color.FromArgb(100, 149, 237),    // Cornflower Blue
                        Secondary = Color.FromArgb(255, 160, 122),  // Light Salmon
                        MainBackgroundStart = Color.FromArgb(30, 30, 30),
                        MainBackgroundEnd = Color.FromArgb(10, 10, 10),
                        PanelBackground = Color.FromArgb(25, 25, 25),
                        MessageText = Color.WhiteSmoke,
                        SnakeBody = Color.FromArgb(200, 100, 149, 237),
                        SnakeHead = Color.WhiteSmoke
                    },

                    GameTheme.Light => new Theme
                    {
                        Primary = Color.FromArgb(30, 144, 255),     // Dodger Blue
                        Secondary = Color.FromArgb(255, 69, 0),     // Orange Red
                        MainBackgroundStart = Color.FromArgb(240, 240, 240),
                        MainBackgroundEnd = Color.FromArgb(255, 255, 255),
                        PanelBackground = Color.FromArgb(230, 230, 230),
                        MessageText = Color.Black,
                        SnakeBody = Color.FromArgb(180, 30, 144, 255),
                        SnakeHead = Color.Black
                    },
                    _ => GetTheme(GameTheme.Neon),
                };
            }
        }

        public enum FoodType { Normal, Fast, Slow, Bonus, Bomb }

        // --- BASE CLASS FOR ALL FOODS ---
        public abstract class FoodBase
        {
            public Point Position { get; set; }
            public FoodType Type { get; protected set; }
            public abstract Color Color { get; }
            public abstract int Points { get; }
            // Pass the game instance to apply effects like speed changes
            public abstract void ApplyEffect(Form1 game);
        }

        // --- NORMAL FOOD CLASS ---
        public class NormalFood : FoodBase
        {
            public NormalFood()
            {
                Type = FoodType.Normal;
            }

            public override Color Color => Color.FromArgb(255, 0, 102); // neon pink
            public override int Points => 10;

            public override void ApplyEffect(Form1 game)
            {
                // Normal food only gives points and growth (growth handled in MoveSnake)
            }
        }

        // --- SPECIAL FOOD CLASS (Fast, Slow, Bonus, Bomb) ---
        public class SpecialFood : FoodBase
        {
            public SpecialFood(FoodType type)
            {
                if (type == FoodType.Normal)
                    throw new ArgumentException("SpecialFood cannot be Normal.");
                Type = type;
            }

            public override Color Color
            {
                get
                {
                    return Type switch
                    {
                        FoodType.Fast => Color.FromArgb(255, 128, 0),// neon orange (speed up)
                        FoodType.Bomb => Color.Purple,               // Bomb color (you used Purple)
                        FoodType.Slow => Color.FromArgb(0, 128, 255),    // neon blue (slow down)
                        FoodType.Bonus => Color.FromArgb(255, 255, 0),   // neon yellow (extra points)
                        _ => Color.Pink

                    };
                }
            }

            public override int Points
            {
                get
                {
                    return Type switch
                    {
                        FoodType.Bomb => 0,
                        FoodType.Bonus => 50, // Bonus food gives 50 points
                        _ => 10,              // Fast/Slow give 10 points (plus their effect)
                    };
                }
            }

            public override void ApplyEffect(Form1 game)
            {
                // Bomb effect
                if (Type == FoodType.Bomb)
                {
                    int removeCount = Math.Min(3, game.snake.Count - 1);

                    for (int i = 0; i < removeCount; i++)
                        game.snake.RemoveAt(game.snake.Count - 1);

                    // Check if snake is now too short
                    if (game.snake.Count <= 3)
                    {
                        game.GameOver();
                        return;
                    }

                    return;
                }

                // Apply speed effect (original code)
                game.temporarySpeedAdjustment = Type switch
                {
                    FoodType.Fast => -30,
                    FoodType.Slow => 30,
                    _ => 0
                };
            }

        }
        // --- Empty/Unused Handlers ---
        private void grpThemeSelector_Enter(object sender, EventArgs e) { }
        private void lblHighScore_Click_1(object sender, EventArgs e) { }
        private void radioButton1_CheckedChanged(object sender, EventArgs e) { }

        private void ResetToThemeColors()
        {
            useCustomColors = false;
            customSnakeHeadColor = customSnakeBodyColor = customBoardColor = customFoodColor = Color.Empty;
            pnlGame.Invalidate();
            this.Invalidate();
        }
        private void btnSetting_Click(object? sender, EventArgs e)
        {
            // Provide current colors (if not set, fall back to theme)
            Color snakeHead = useCustomColors && customSnakeHeadColor != Color.Empty ? customSnakeHeadColor : currentTheme.SnakeHead;
            Color snakeBody = useCustomColors && customSnakeBodyColor != Color.Empty ? customSnakeBodyColor : ControlPaint.Dark(currentTheme.SnakeHead, 0.2f);
            Color board = useCustomColors && customBoardColor != Color.Empty ? customBoardColor : currentTheme.PanelBackground;
            Color food = useCustomColors && customFoodColor != Color.Empty ? customFoodColor : Color.Red; // default food color

            using (var dlg = new SettingsForm(snakeHead, snakeBody, board, food, soundEnabled))
            {
                var result = dlg.ShowDialog(this);
                if (result == DialogResult.OK)
                {
                    // Apply chosen values
                    customSnakeHeadColor = dlg.SelectedSnakeHead;
                    customSnakeBodyColor = ControlPaint.Dark(dlg.SelectedSnakeHead, 0.2f);
                    customBoardColor = dlg.SelectedBoard;
                    customFoodColor = dlg.SelectedFood;

                    useCustomColors = true;        
                    soundEnabled = dlg.EnableSound;

                    // repaint the game area and form
                    pnlGame.Invalidate();
                    this.Invalidate();
                }
                // if Cancel, do nothing
            }
        }

        private void pnlGame_SizeChanged(object sender, EventArgs e)
        {
            if (pnlGame.Width <= 0 || pnlGame.Height <= 0) return;

            // Calculate width and height separately to FILL the screen
            cellWidth = (float)pnlGame.Width / cols;
            cellHeight = (float)pnlGame.Height / rows;

            pnlGame.Invalidate();
        }

        private void lblMessage_Click(object sender, EventArgs e)
        {

        }
    }
}