﻿namespace snakeassignment
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlGame = new Panel();
            lblMessage = new Label();
            btnRestart = new Button();
            btnStart = new Button();
            btnPause = new Button();
            lblScore = new Label();
            lblHighScore = new Label();
            rdoSpeedExtreme = new RadioButton();
            rdoSpeedFast = new RadioButton();
            rdoSpeedNormal = new RadioButton();
            rdoSpeedSlow = new RadioButton();
            rdoVerySlow = new RadioButton();
            grpSpeedSelector = new GroupBox();
            grpThemeSelector = new GroupBox();
            rdoDarkTheme = new RadioButton();
            rdoNeonTheme = new RadioButton();
            rdoLightTheme = new RadioButton();
            btnSetting = new Button();
            pnlGame.SuspendLayout();
            grpSpeedSelector.SuspendLayout();
            grpThemeSelector.SuspendLayout();
            SuspendLayout();
            // 
            // pnlGame
            // 
            pnlGame.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlGame.BackColor = Color.White;
            pnlGame.Controls.Add(lblMessage);
            pnlGame.Location = new Point(23, 80);
            pnlGame.Name = "pnlGame";
            pnlGame.Size = new Size(620, 600);
            pnlGame.TabIndex = 0;
            pnlGame.SizeChanged += pnlGame_SizeChanged;
            pnlGame.Paint += pnlGame_Paint;
            // 
            // lblMessage
            // 
            lblMessage.BackColor = Color.MediumAquamarine;
            lblMessage.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMessage.ForeColor = Color.Black;
            lblMessage.ImageAlign = ContentAlignment.BottomRight;
            lblMessage.Location = new Point(143, 207);
            lblMessage.Name = "lblMessage";
            lblMessage.Padding = new Padding(1);
            lblMessage.Size = new Size(300, 100);
            lblMessage.TabIndex = 0;
            lblMessage.Text = "\"PRESS 'START GAME' TO BEGIN.\\nUSE ARROW KEYS TO MOVE.\"";
            lblMessage.TextAlign = ContentAlignment.MiddleCenter;
            lblMessage.Click += lblMessage_Click;
            // 
            // btnRestart
            // 
            btnRestart.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnRestart.AutoSize = true;
            btnRestart.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRestart.Location = new Point(781, 29);
            btnRestart.Name = "btnRestart";
            btnRestart.Padding = new Padding(1);
            btnRestart.Size = new Size(123, 33);
            btnRestart.TabIndex = 4;
            btnRestart.Text = "Restart Game";
            btnRestart.UseVisualStyleBackColor = true;
            btnRestart.Click += btnRestart_Click;
            // 
            // btnStart
            // 
            btnStart.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnStart.AutoSize = true;
            btnStart.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnStart.Location = new Point(781, 29);
            btnStart.Name = "btnStart";
            btnStart.Padding = new Padding(1);
            btnStart.Size = new Size(106, 33);
            btnStart.TabIndex = 2;
            btnStart.Text = "Start Game";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // btnPause
            // 
            btnPause.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnPause.AutoSize = true;
            btnPause.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPause.Location = new Point(791, 29);
            btnPause.Name = "btnPause";
            btnPause.Padding = new Padding(1);
            btnPause.Size = new Size(75, 33);
            btnPause.TabIndex = 3;
            btnPause.Text = "Pause";
            btnPause.UseVisualStyleBackColor = true;
            btnPause.Click += btnPause_Click;
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblScore.Location = new Point(40, 29);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(69, 21);
            lblScore.TabIndex = 0;
            lblScore.Text = "Score: 0";
            // 
            // lblHighScore
            // 
            lblHighScore.AutoSize = true;
            lblHighScore.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHighScore.Location = new Point(425, 29);
            lblHighScore.Name = "lblHighScore";
            lblHighScore.Size = new Size(106, 21);
            lblHighScore.TabIndex = 1;
            lblHighScore.Text = "HighScore: 0";
            lblHighScore.Click += lblHighScore_Click_1;
            // 
            // rdoSpeedExtreme
            // 
            rdoSpeedExtreme.AutoSize = true;
            rdoSpeedExtreme.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rdoSpeedExtreme.Location = new Point(35, 36);
            rdoSpeedExtreme.Name = "rdoSpeedExtreme";
            rdoSpeedExtreme.Size = new Size(122, 21);
            rdoSpeedExtreme.TabIndex = 9;
            rdoSpeedExtreme.TabStop = true;
            rdoSpeedExtreme.Text = "Extreme (50ms)";
            rdoSpeedExtreme.UseVisualStyleBackColor = true;
            // 
            // rdoSpeedFast
            // 
            rdoSpeedFast.AutoSize = true;
            rdoSpeedFast.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rdoSpeedFast.Location = new Point(35, 72);
            rdoSpeedFast.Name = "rdoSpeedFast";
            rdoSpeedFast.Size = new Size(104, 21);
            rdoSpeedFast.TabIndex = 10;
            rdoSpeedFast.TabStop = true;
            rdoSpeedFast.Text = "Fast (100ms)";
            rdoSpeedFast.UseVisualStyleBackColor = true;
            // 
            // rdoSpeedNormal
            // 
            rdoSpeedNormal.AutoSize = true;
            rdoSpeedNormal.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rdoSpeedNormal.Location = new Point(34, 110);
            rdoSpeedNormal.Name = "rdoSpeedNormal";
            rdoSpeedNormal.Size = new Size(125, 21);
            rdoSpeedNormal.TabIndex = 11;
            rdoSpeedNormal.TabStop = true;
            rdoSpeedNormal.Text = "Normal (150ms)";
            rdoSpeedNormal.UseVisualStyleBackColor = true;
            // 
            // rdoSpeedSlow
            // 
            rdoSpeedSlow.AutoSize = true;
            rdoSpeedSlow.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rdoSpeedSlow.Location = new Point(34, 149);
            rdoSpeedSlow.Name = "rdoSpeedSlow";
            rdoSpeedSlow.Size = new Size(108, 21);
            rdoSpeedSlow.TabIndex = 12;
            rdoSpeedSlow.TabStop = true;
            rdoSpeedSlow.Text = "Slow (200ms)";
            rdoSpeedSlow.UseVisualStyleBackColor = true;
            // 
            // rdoVerySlow
            // 
            rdoVerySlow.AutoSize = true;
            rdoVerySlow.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rdoVerySlow.Location = new Point(34, 185);
            rdoVerySlow.Name = "rdoVerySlow";
            rdoVerySlow.Size = new Size(140, 21);
            rdoVerySlow.TabIndex = 13;
            rdoVerySlow.TabStop = true;
            rdoVerySlow.Text = "Very Slow (250ms)";
            rdoVerySlow.UseVisualStyleBackColor = true;
            // 
            // grpSpeedSelector
            // 
            grpSpeedSelector.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            grpSpeedSelector.BackColor = SystemColors.Control;
            grpSpeedSelector.Controls.Add(rdoSpeedNormal);
            grpSpeedSelector.Controls.Add(rdoVerySlow);
            grpSpeedSelector.Controls.Add(rdoSpeedExtreme);
            grpSpeedSelector.Controls.Add(rdoSpeedSlow);
            grpSpeedSelector.Controls.Add(rdoSpeedFast);
            grpSpeedSelector.Location = new Point(738, 362);
            grpSpeedSelector.Name = "grpSpeedSelector";
            grpSpeedSelector.Size = new Size(200, 234);
            grpSpeedSelector.TabIndex = 14;
            grpSpeedSelector.TabStop = false;
            grpSpeedSelector.Text = "Speed Selector";
            // 
            // grpThemeSelector
            // 
            grpThemeSelector.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            grpThemeSelector.BackColor = SystemColors.Control;
            grpThemeSelector.Controls.Add(rdoDarkTheme);
            grpThemeSelector.Controls.Add(rdoNeonTheme);
            grpThemeSelector.Controls.Add(rdoLightTheme);
            grpThemeSelector.Location = new Point(738, 170);
            grpThemeSelector.Name = "grpThemeSelector";
            grpThemeSelector.Size = new Size(200, 173);
            grpThemeSelector.TabIndex = 8;
            grpThemeSelector.TabStop = false;
            grpThemeSelector.Text = "Theme Selection";
            grpThemeSelector.Enter += grpThemeSelector_Enter;
            // 
            // rdoDarkTheme
            // 
            rdoDarkTheme.AutoSize = true;
            rdoDarkTheme.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rdoDarkTheme.Location = new Point(35, 72);
            rdoDarkTheme.Name = "rdoDarkTheme";
            rdoDarkTheme.Size = new Size(101, 21);
            rdoDarkTheme.TabIndex = 6;
            rdoDarkTheme.TabStop = true;
            rdoDarkTheme.Text = "Dark Theme";
            rdoDarkTheme.UseVisualStyleBackColor = true;
            rdoDarkTheme.CheckedChanged += rdoDarkTheme_CheckedChanged;
            // 
            // rdoNeonTheme
            // 
            rdoNeonTheme.AutoSize = true;
            rdoNeonTheme.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rdoNeonTheme.Location = new Point(35, 110);
            rdoNeonTheme.Name = "rdoNeonTheme";
            rdoNeonTheme.Size = new Size(105, 21);
            rdoNeonTheme.TabIndex = 7;
            rdoNeonTheme.TabStop = true;
            rdoNeonTheme.Text = "Neon Theme";
            rdoNeonTheme.UseVisualStyleBackColor = true;
            rdoNeonTheme.CheckedChanged += rdoNeonTheme_CheckedChanged;
            // 
            // rdoLightTheme
            // 
            rdoLightTheme.AutoSize = true;
            rdoLightTheme.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rdoLightTheme.Location = new Point(35, 36);
            rdoLightTheme.Name = "rdoLightTheme";
            rdoLightTheme.Size = new Size(104, 21);
            rdoLightTheme.TabIndex = 5;
            rdoLightTheme.TabStop = true;
            rdoLightTheme.Text = "Light Theme";
            rdoLightTheme.UseVisualStyleBackColor = true;
            rdoLightTheme.CheckedChanged += rdoLightTheme_CheckedChanged;
            // 
            // btnSetting
            // 
            btnSetting.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSetting.BackColor = Color.MediumAquamarine;
            btnSetting.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSetting.Location = new Point(797, 98);
            btnSetting.Name = "btnSetting";
            btnSetting.Size = new Size(90, 36);
            btnSetting.TabIndex = 15;
            btnSetting.Text = "Setting";
            btnSetting.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1001, 701);
            Controls.Add(btnSetting);
            Controls.Add(grpSpeedSelector);
            Controls.Add(lblHighScore);
            Controls.Add(grpThemeSelector);
            Controls.Add(btnRestart);
            Controls.Add(lblScore);
            Controls.Add(btnPause);
            Controls.Add(pnlGame);
            Controls.Add(btnStart);
            KeyPreview = true;
            MinimizeBox = false;
            Name = "Form1";
            Text = "Snake Game";
            WindowState = FormWindowState.Maximized;
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            pnlGame.ResumeLayout(false);
            grpSpeedSelector.ResumeLayout(false);
            grpSpeedSelector.PerformLayout();
            grpThemeSelector.ResumeLayout(false);
            grpThemeSelector.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlGame;
        private Label lblScore;
        protected internal Label lblHighScore;
        private Button btnStart;
        private Button btnPause;
        private Label lblMessage;
        private Button btnRestart;
        private RadioButton rdoSpeedExtreme;
        private RadioButton rdoSpeedFast;
        private RadioButton rdoSpeedNormal;
        private RadioButton rdoSpeedSlow;
        private RadioButton rdoVerySlow;
        private GroupBox grpSpeedSelector;
        private GroupBox grpThemeSelector;
        private RadioButton rdoDarkTheme;
        private RadioButton rdoNeonTheme;
        private RadioButton rdoLightTheme;
        private Button btnSetting;

    }
}
