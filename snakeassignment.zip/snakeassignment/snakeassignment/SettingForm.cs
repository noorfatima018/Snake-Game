﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel; // Required for the IContainer definition

namespace snakeassignment
{
    // The 'partial' keyword is essential here because the rest of the class is in the Designer.cs file
    public partial class SettingsForm : Form
    {
        private Button btnSnakeColor;
        private Button btnBoardColor;
        private Button btnFoodColor;
        private CheckBox chkEnableSound;
        private Button btnOk;
        private Button btnCancel;

        private Panel previewSnake;
        private Panel previewBoard;
        private Panel previewFood;

        private Color tempSnakeHead;
        private Color tempSnakeBody;
        private Color tempBoard;
        private Color tempFood;
        private bool tempSoundEnabled;

        // Note: The 'components' variable is now declared ONLY in the Designer.cs file 
        // to avoid the CS0229 Ambiguity error.

        // Expose the selected values
        public Color SelectedSnakeHead => tempSnakeHead;
        public Color SelectedBoard => tempBoard;
        public Color SelectedFood => tempFood;
        public bool EnableSound => tempSoundEnabled;

        public SettingsForm(Color currentSnakeHead, Color currentSnakeBody, Color currentBoard, Color currentFood, bool currentSoundEnabled)
        {
            // 1. Initialize data variables
            tempSnakeHead = currentSnakeHead;
            tempSnakeBody = currentSnakeBody;
            tempBoard = currentBoard;
            tempFood = currentFood;
            tempSoundEnabled = currentSoundEnabled;

            // 2. Initialize Component Objects (Controls) - ONLY creation
            btnSnakeColor = new Button { Text = "Snake Color" };
            btnBoardColor = new Button { Text = "Board Color" };
            btnFoodColor = new Button { Text = "Food Color" };

            previewSnake = new Panel { BackColor = tempSnakeHead, BorderStyle = BorderStyle.FixedSingle };
            previewBoard = new Panel { BackColor = tempBoard, BorderStyle = BorderStyle.FixedSingle };
            previewFood = new Panel { BackColor = tempFood, BorderStyle = BorderStyle.FixedSingle };

            chkEnableSound = new CheckBox { Text = "Enable Sound", Checked = tempSoundEnabled };

            btnOk = new Button { Text = "OK", DialogResult = DialogResult.OK };
            btnCancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel };

            // 3. Form Setup (Basic properties that are usually fixed)
            this.Text = "Settings";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 420;
            this.Height = 260;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;

            // *** NEW: CALL THE DESIGN METHOD FROM THE UISetting.cs FILE ***
             DesignControls();

            // 4. Attach Event Handlers
            btnSnakeColor.Click += BtnSnakeColor_Click;
            btnBoardColor.Click += BtnBoardColor_Click;
            btnFoodColor.Click += BtnFoodColor_Click;

            btnOk.Click += BtnOk_Click;
            btnCancel.Click += (s, e) => this.Close();

            // 5. Add Controls to Form
            this.Controls.Add(btnSnakeColor);
            this.Controls.Add(btnBoardColor);
            this.Controls.Add(btnFoodColor);
            this.Controls.Add(previewSnake);
            this.Controls.Add(previewBoard);
            this.Controls.Add(previewFood);
            this.Controls.Add(chkEnableSound);
            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);

            AcceptButton = btnOk;
            CancelButton = btnCancel;
        }

        // FIX: Added the missing method to resolve CS1061 
        private void SettingForm_Load(object sender, EventArgs e)
        {
            // Any code you want to run when the settings form loads goes here
        }

        private void BtnSnakeColor_Click(object? sender, EventArgs e)
        {
            using (ColorDialog dlg = new ColorDialog())
            {
                dlg.Color = tempSnakeHead;
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    tempSnakeHead = dlg.Color;

                    // Safe logic for darkening the snake body color
                    Color baseColor = dlg.Color;
                    tempSnakeBody = Color.FromArgb(
                        Math.Max(0, baseColor.R - 50),
                        Math.Max(0, baseColor.G - 50),
                        Math.Max(0, baseColor.B - 50));

                    previewSnake.BackColor = tempSnakeHead;
                }
            }
        }

        private void BtnBoardColor_Click(object? sender, EventArgs e)
        {
            using (ColorDialog dlg = new ColorDialog())
            {
                dlg.Color = tempBoard;
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    tempBoard = dlg.Color;
                    previewBoard.BackColor = tempBoard;
                }
            }
        }

        private void BtnFoodColor_Click(object? sender, EventArgs e)
        {
            using (ColorDialog dlg = new ColorDialog())
            {
                dlg.Color = tempFood;
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    tempFood = dlg.Color;
                    previewFood.BackColor = tempFood;
                }
            }
        }

        private void BtnOk_Click(object? sender, EventArgs e)
        {
            tempSoundEnabled = chkEnableSound.Checked;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}