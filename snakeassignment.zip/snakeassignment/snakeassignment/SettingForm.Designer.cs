﻿namespace snakeassignment
{
    partial class SettingsForm // Class name must match the main file
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        // FIX: The sole declaration of components to fix CS0229
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            // FIX: Added 'this.' to all methods/properties
            this.SuspendLayout();

            // 
            // SettingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 630);

            // Note: The correct type for GraphicsUnit must be used.
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SettingsForm";
            this.Text = "SettingsForm";

            // Event hookup requires the method to exist in SettingsForm.cs (which we added above)
            this.Load += new System.EventHandler(this.SettingForm_Load);

            this.ResumeLayout(false);
        }

        #endregion
    }
}